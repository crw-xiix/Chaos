#pragma once

#include <array>
#include <list>
#include <string>
#include <vector>

#include <iostream>
#include <sstream>
#include <fstream>

#include <functional>
#include <memory>

#include <SDL/SDL.h>